import random

class MockSMSProvider:
    def request_number(self, server, provider_country_id):
        return {'order_id': f'DEMO-{random.randint(10000,99999)}', 'phone': '+20 10XX XXX XXXX'}
    def check_code(self, order_id):
        return None
    def cancel(self, order_id):
        return True
