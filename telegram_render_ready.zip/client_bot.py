import asyncio, os
from datetime import datetime, timedelta
from dotenv import load_dotenv
from aiogram import Bot, Dispatcher, F
from aiogram.filters import CommandStart
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
import db
from provider import MockSMSProvider

load_dotenv(); TOKEN=os.getenv('CLIENT_BOT_TOKEN'); provider=MockSMSProvider(); dp=Dispatcher(); pending={}

def kb(rows): return InlineKeyboardMarkup(inline_keyboard=rows)

@dp.message(CommandStart())
async def start(m:Message):
    u=db.user(m.from_user.id,m.from_user.username or '')
    if u['banned']: return await m.answer('🚫 حسابك محظور.')
    await m.answer(f'مرحبًا 👋\nرصيدك: {u["balance"]} نقطة', reply_markup=kb([[InlineKeyboardButton(text='📱 شراء رقم',callback_data='buy')],[InlineKeyboardButton(text='📊 تقرير العمليات',callback_data='report'),InlineKeyboardButton(text='💳 إضافة رصيد',callback_data='topup')]]))

@dp.callback_query(F.data=='topup')
async def topup(q:CallbackQuery): await q.message.answer(db.get_setting('topup_message')); await q.answer()

@dp.callback_query(F.data=='buy')
async def buy(q:CallbackQuery):
    await q.message.edit_text('اختر السيرفر:',reply_markup=kb([[InlineKeyboardButton(text='Ahlan',callback_data='srv:Ahlan')],[InlineKeyboardButton(text='Any Other',callback_data='srv:Any Other')]])); await q.answer()

@dp.callback_query(F.data.startswith('srv:'))
async def server(q:CallbackQuery):
    s=q.data[4:]; c=db.conn(); rows=c.execute('SELECT * FROM countries WHERE server=? AND enabled=1',(s,)).fetchall(); c.close()
    buttons=[[InlineKeyboardButton(text=f'{r["name"]} — {r["price"]} نقطة',callback_data=f'country:{r["id"]}')] for r in rows]
    await q.message.edit_text(f'الدول المتاحة في {s}:',reply_markup=kb(buttons or [[InlineKeyboardButton(text='لا توجد دول',callback_data='noop')]])); await q.answer()

@dp.callback_query(F.data.startswith('country:'))
async def country(q:CallbackQuery):
    cid=int(q.data.split(':')[1]); c=db.conn(); r=c.execute('SELECT * FROM countries WHERE id=?',(cid,)).fetchone(); u=db.user(q.from_user.id,q.from_user.username or '')
    if not r or u['balance']<r['price']: c.close(); return await q.answer('الرصيد غير كافٍ.',show_alert=True)
    x=provider.request_number(r['server'],r['provider_id']); created=datetime.utcnow(); c.execute('INSERT INTO orders(telegram_id,server,country_id,provider_order_id,phone,price,status,created_at) VALUES(?,?,?,?,?,?,?,?)',(q.from_user.id,r['server'],cid,x['order_id'],x['phone'],r['price'],'pending',created.isoformat())); oid=c.execute('SELECT last_insert_rowid()').fetchone()[0]; c.commit(); c.close(); pending[q.from_user.id]={'oid':oid,'provider':x['order_id'],'price':r['price'],'expires':created+timedelta(seconds=180)}
    await q.message.edit_text(f'📱 الرقم: `{x["phone"]}`\n⏳ المهلة: 180 ثانية\n\nهذه نسخة تجريبية، ولا يتم استقبال كود حقيقي.',parse_mode='Markdown',reply_markup=kb([[InlineKeyboardButton(text='❌ إلغاء بعد 90 ثانية',callback_data=f'cancel:{oid}')]])); await q.answer()

@dp.callback_query(F.data.startswith('cancel:'))
async def cancel(q:CallbackQuery):
    p=pending.get(q.from_user.id)
    if not p or p['oid']!=int(q.data.split(':')[1]): return await q.answer('لا توجد عملية نشطة.',show_alert=True)
    # Demo: cancellation button is available only after 90s by timestamp check stored in memory.
    started=p['expires']-timedelta(seconds=180)
    if datetime.utcnow()<started+timedelta(seconds=90): return await q.answer('يمكن الإلغاء بعد مرور 90 ثانية.',show_alert=True)
    c=db.conn(); c.execute("UPDATE orders SET status='cancelled',completed_at=? WHERE id=? AND status='pending'",(datetime.utcnow().isoformat(),p['oid'])); c.commit(); c.close(); pending.pop(q.from_user.id,None); await q.message.edit_text('تم إلغاء العملية بدون خصم.'); await q.answer()

@dp.callback_query(F.data=='report')
async def report(q:CallbackQuery):
    since=(datetime.utcnow()-timedelta(days=5)).isoformat(); c=db.conn(); rows=c.execute("SELECT status,COUNT(*) n FROM orders WHERE telegram_id=? AND created_at>=? GROUP BY status",(q.from_user.id,since)).fetchall(); c.close(); d={r['status']:r['n'] for r in rows}; await q.message.answer(f'📊 آخر 5 أيام\nناجحة: {d.get("success",0)}\nفاشلة: {d.get("failed",0)}'); await q.answer()

async def main(): await dp.start_polling(Bot(TOKEN))
if __name__=='__main__': asyncio.run(main())
