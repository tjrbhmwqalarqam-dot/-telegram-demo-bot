# Telegram Two-Bot Demo

نسخة تجريبية آمنة لبوت عميل + بوت أدمن، مع مزود SMS تجريبي Mock.

## التشغيل
1. Python 3.11+
2. `pip install -r requirements.txt`
3. انسخ `.env.example` إلى `.env` وضع توكني البوتين وTelegram ID للأدمن.
4. `python client_bot.py` و `python admin_bot.py` في نافذتين.

> مزود SMS هنا تجريبي ولا يتعامل مع أرقام أو أكواد حقيقية.
