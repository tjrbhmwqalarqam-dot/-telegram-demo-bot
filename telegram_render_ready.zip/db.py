import sqlite3
from datetime import datetime, timedelta

DB='bot.db'
def conn():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c

def init():
    c=conn(); c.executescript('''
    CREATE TABLE IF NOT EXISTS users(telegram_id INTEGER PRIMARY KEY, username TEXT, balance INTEGER NOT NULL DEFAULT 0, banned INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS countries(id INTEGER PRIMARY KEY AUTOINCREMENT, server TEXT NOT NULL, name TEXT NOT NULL, provider_id TEXT NOT NULL, price INTEGER NOT NULL, enabled INTEGER NOT NULL DEFAULT 1);
    CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY AUTOINCREMENT, telegram_id INTEGER NOT NULL, server TEXT, country_id INTEGER, provider_order_id TEXT, phone TEXT, code TEXT, price INTEGER, status TEXT, created_at TEXT, completed_at TEXT);
    CREATE TABLE IF NOT EXISTS transactions(id INTEGER PRIMARY KEY AUTOINCREMENT, telegram_id INTEGER, amount INTEGER, type TEXT, admin_id INTEGER, created_at TEXT);
    CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
    '''); c.commit(); c.close()

def now(): return datetime.utcnow().isoformat()

def user(tid, username=''):
    c=conn(); c.execute('INSERT OR IGNORE INTO users(telegram_id,username,created_at) VALUES(?,?,?)',(tid,username,now())); c.commit(); r=c.execute('SELECT * FROM users WHERE telegram_id=?',(tid,)).fetchone(); c.close(); return r

def set_setting(k,v):
    c=conn(); c.execute('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',(k,v)); c.commit(); c.close()

def get_setting(k,default=''): 
    c=conn(); r=c.execute('SELECT value FROM settings WHERE key=?',(k,)).fetchone(); c.close(); return r['value'] if r else default

def add_balance(tid, amount, admin_id):
    c=conn(); c.execute('UPDATE users SET balance=balance+? WHERE telegram_id=?',(amount,tid)); c.execute('INSERT INTO transactions(telegram_id,amount,type,admin_id,created_at) VALUES(?,?,?,?,?)',(tid,amount,'add',admin_id,now())); c.commit(); c.close()

def remove_balance(tid, amount, admin_id): add_balance(tid,-amount,admin_id)

def seed():
    c=conn();
    if c.execute('SELECT COUNT(*) n FROM countries').fetchone()['n']==0:
        c.executemany('INSERT INTO countries(server,name,provider_id,price) VALUES(?,?,?,?)',[('Ahlan','Demo Country','demo',10),('Any Other','Demo Country','demo2',15)])
    if not get_setting('topup_message'): set_setting('topup_message','لإضافة رصيد تواصل مع الإدارة.')
    c.commit(); c.close()
init(); seed()
