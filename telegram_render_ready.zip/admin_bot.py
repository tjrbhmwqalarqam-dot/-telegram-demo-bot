import asyncio, os
from datetime import datetime,timedelta
from dotenv import load_dotenv
from aiogram import Bot,Dispatcher,F
from aiogram.filters import CommandStart
from aiogram.types import Message,CallbackQuery,InlineKeyboardMarkup,InlineKeyboardButton
import db
load_dotenv(); TOKEN=os.getenv('ADMIN_BOT_TOKEN'); ADMIN_ID=int(os.getenv('ADMIN_ID','0')); dp=Dispatcher()
def ok(m): return m.from_user.id==ADMIN_ID
def kb(rows): return InlineKeyboardMarkup(inline_keyboard=rows)
@dp.message(CommandStart())
async def start(m:Message):
 if not ok(m): return
 await m.answer('لوحة الأدمن',reply_markup=kb([[InlineKeyboardButton(text='👥 المستخدمون',callback_data='users')],[InlineKeyboardButton(text='🌍 الدول',callback_data='countries')],[InlineKeyboardButton(text='📋 العمليات',callback_data='orders')],[InlineKeyboardButton(text='💳 رسالة الرصيد',callback_data='msg')]]))
@dp.callback_query(F.data=='users')
async def users(q:CallbackQuery):
 c=db.conn(); rs=c.execute('SELECT telegram_id,balance,banned FROM users ORDER BY telegram_id').fetchall(); c.close(); text='\n'.join(f'{r["telegram_id"]}: {r["balance"]} نقطة | '+('محظور' if r['banned'] else 'نشط') for r in rs) or 'لا يوجد مستخدمون'; await q.message.answer(text); await q.answer()
@dp.callback_query(F.data=='countries')
async def countries(q:CallbackQuery):
 c=db.conn(); rs=c.execute('SELECT id,server,name,provider_id,price,enabled FROM countries').fetchall(); c.close(); text='\n'.join(f'#{r["id"]} | {r["server"]} | {r["name"]} | {r["provider_id"]} | {r["price"]} نقطة' for r in rs) or 'لا توجد دول'; await q.message.answer(text+'\n\nللتعديل البرمجي المباشر استخدم قاعدة البيانات في النسخة التجريبية.'); await q.answer()
@dp.callback_query(F.data=='orders')
async def orders(q:CallbackQuery):
 since=(datetime.utcnow()-timedelta(days=5)).isoformat(); c=db.conn(); rs=c.execute('SELECT telegram_id,server,price,status,created_at FROM orders WHERE created_at>=? ORDER BY id DESC',(since,)).fetchall(); c.close(); text='\n'.join(f'{r["telegram_id"]} | {r["server"]} | {r["price"]} | {r["status"]}' for r in rs) or 'لا توجد عمليات'; await q.message.answer(text); await q.answer()
@dp.callback_query(F.data=='msg')
async def msg(q:CallbackQuery): await q.message.answer('لتغيير الرسالة في هذه النسخة: عدّل setting topup_message في قاعدة البيانات.'); await q.answer()
async def main(): await dp.start_polling(Bot(TOKEN))
if __name__=='__main__': asyncio.run(main())
